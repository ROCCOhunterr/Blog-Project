<?php
if(isset($_POST['login'])){
    include "config.php";
    $username = mysqli_real_escape_string($con, $_POST['userName']);
    $password = mysqli_real_escape_string($con, md5($_POST['password']));

    $sql = "SELECT id, userName, choose FROM user WHERE userName= '{$username}' AND password= '{$password}'";
    $result = mysqli_query($con, $sql) or die("Query Failed.");
    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
            session_start();
            $_SESSION["id"] = $row['id'];
            $_SESSION["username"] = $row['userName'];
            $_SESSION["rol"] = $row['choose'];
            header("Location: user.php");
            exit(0);
        }
    }
    else{
        echo "Username and Password are not matched.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Simple Bloger/User Interface</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
	<div class="container p-5">
        <div class="row justify-content-center align-items-center h-100">
            <h1>Login Blogger/User</h1>
            <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
                <div class="form-outline mb-4">
                    <label class="form-label" for="form2Example1">UserName:</label>
                    <input type="text" name="userName" class="form-control" placeholder="User Name" />
                </div>
                <div class="form-outline mb-4">
                    <label class="form-label" for="form2Example2">Password:</label>
                    <input type="text" name="password" class="form-control" placeholder="Password" />
                </div>
                <input class="btn btn-primary btn-lg" type="submit" value="Sign in" name="login" />
                <div class="row mb-4">
                    <div class="col-6">
                        <a href="#!">Forgot password?</a>
                    </div>
                    <div class="col-6 text-center">
                        <p>Not a member? <a href="registration.php">Register</a></p>
                    </div>
                </div>
            </form>
        </div>
	</div>
</body>
</html>