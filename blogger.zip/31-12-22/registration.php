<?php
if(isset($_POST['register'])){
    include "config.php";
    $username = mysqli_real_escape_string($con, $_POST['userName']);
    $password = mysqli_real_escape_string($con, md5($_POST['password']));
    $confimpassword = mysqli_real_escape_string($con, md5($_POST['cpassword']));
    $birthdayDate = mysqli_real_escape_string($con, $_POST['birthdayDate']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $email1 = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $chooseop = mysqli_real_escape_string($con, $_POST['choose']);

    $sql = "SELECT userName FROM user WHERE userName = '{$username}'";
    $result = mysqli_query($con, $sql) or die("Query Failed.");
    if(mysqli_num_rows($result) > 0){
        echo "UserName Already Exists";
    }
    else{
    $userQuery = "INSERT INTO user(userName, password, birthdayDate, gender, email, phone, choose) 
    VALUES('$username', '$password', '$birthdayDate', '$gender', '$email1', '$phone', '$chooseop')";
    $userQueryRun = mysqli_query($con, $userQuery) or die("Query Unsuccessful.");
    if(mysqli_query($con, $userQuery)){
    echo "Registered Successfully";
    header("Location: login.php");
    exit(0);
    }
    else{
    echo "Something Went Wrong!";
    header("Location: registration.php");
    exit(0);
    }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Simple Bloger/User Interface</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <section class="vh-100 gradient-custom">
    <div class="container py-5 h-100">
        <div class="row justify-content-center align-items-center h-100">
        <div class="col-12 col-lg-9 col-xl-7">
            <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
            <div class="card-body p-4 p-md-5">
                <h3 class="mb-4 pb-2 pb-md-0 mb-md-5 text-center">User/Blogger Registration Form</h3>
                <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-outline">
                            <label class="form-label" for="firstName">UserName:</label>
                            <input required type="text" name="userName" class="form-control form-control-lg" placeholder="UserName" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-outline">
                            <label class="form-label" for="emailAddress">Email:</label>
                            <input required type="email" name="email" class="form-control form-control-lg" placeholder="Email" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-4 d-flex align-items-center">
                    <div class="form-outline datepicker w-100">
                        <label for="birthdayDate" class="form-label">Date of Birth</label>
                        <input required type="date" class="form-control" name="birthdayDate" />
                    </div>
                    </div>
                    <div class="col-md-6 mb-4">
                    <h6 class="mb-2 pb-1">Gender: </h6>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" value="option1" checked />
                        <label class="form-check-label" for="femaleGender">Female</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" value="option2" />
                        <label class="form-check-label" for="maleGender">Male</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" value="option3" />
                        <label class="form-check-label" for="otherGender">Other</label>
                    </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-4 pb-2">
                        <label class="form-label" for="password">Choose Option:</label><br>
                        <select required name="choose" class="select form-control-lg">
                            <option value="" disable>Choose option</option>
                            <option value="1">Blogger</option>
                            <option value="2">Normal User</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-4 pb-2">
                    <div class="form-outline">
                        <label class="form-label" for="phoneNumber">Phone Number:</label>
                        <input required type="tel" name="phone" class="form-control form-control-lg" placeholder="Phone Number" />
                    </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-4 pb-2">
                        <div class="form-outline">
                            <label class="form-label" for="password">Password:</label>
                            <input required type="text" name="password" class="form-control form-control-lg" placeholder="Password" />
                        </div>
                    </div>
                    <!-- <div class="col-md-6 mb-4 pb-2">
                        <div class="form-outline">
                        <label class="form-label" for="password">Confim Password:</label>
                            <input required type="text" name="cpassword" class="form-control form-control-lg" placeholder="Confim Password" />
                        </div>
                    </div> -->
                </div>
                <div class="mt-4 pt-2">
                    <input class="btn btn-primary btn-lg" type="submit" value="Submit" name="register" />
                </div>
                <div class="text-center">
                    <p>Already registered User/Blogger <a href="login.php">Login</a></p>
                </div>
                </form>
            </div>
            </div>
        </div>
        </div>
    </div>
    </section>
</body>
</html>




