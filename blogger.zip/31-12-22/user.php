<?php include('config.php');
    session_start();
    $uname = $_SESSION["username"];

    if (isset($_POST["blogcomment"]))
    {
        $comment = mysqli_real_escape_string($con, $_POST["comment"]);
        $post_id = mysqli_real_escape_string($con, $_POST["post_id"]);
        $reply_id = 0;
        $query = "INSERT INTO comments(comment, reply_id, post_id, userName) 
        VALUES('$comment', '$reply_id', '$post_id', '$uname')";
        if(mysqli_query($con, $query)){ 
            header("Location: user.php");
            exit(0);
        }
        else{
            echo "Something Went Wrong!";
        }
    }

    if (isset($_POST["reply"]))
    {
        $comment = mysqli_real_escape_string($con, $_POST["comment"]);
        $post_id = mysqli_real_escape_string($con, $_POST["post_id"]);
        $reply_id = mysqli_real_escape_string($con, $_POST["reply_id"]);
        $query1 = "INSERT INTO comments(comment, reply_id, post_id, userName) 
        VALUES('$comment', '$reply_id', '$post_id', '$uname')";
        if(mysqli_query($con, $query1)){
            header("Location: user.php");
            exit(0);
        }
        else{
            echo "Something Went Wrong!";
        }
    }
    $query2 = "SELECT * FROM comments";
    $result2 = mysqli_query($con, $query2);
    $comments = array();
    while ($row = mysqli_fetch_object($result2))
    {
        array_push($comments, $row);
    }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Simple Bloger/User Interface</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <script>
        function showReplyForm(self) {
            var commentId = self.getAttribute("data-id");
            if (document.getElementById("form-" + commentId).style.display == "") {
                document.getElementById("form-" + commentId).style.display = "none";
            } else {
                document.getElementById("form-" + commentId).style.display = "";
            }
        }
    </script>
</head>
<body>
    <div class="container-fluid" id="header">
        <div class="container-fluid p-4" id="dashboard">
            <div class="row text-center h-100">
                <div class="col-4">
                    <h3>Blogger Dashboard</h3>
                </div>
                <div class="col-8">
                    <h3>Hello <?php echo $_SESSION["username"]; ?>, <a href="logout.php" class="admin-logout">Logout</a></h3>
                </div>
            </div>
        </div>
        <div class="container p-1" id="userBloger">
            <div class="d-grid gap-2 d-md-block">
                <a class="btn" href="user.php" role="button">Blogs</a>
                <?php include('config.php');
                    if($_SESSION["rol"] == '1'){
                ?>
                    <a class="btn" href="blogger.php" role="button">Blogs List</a>
                <?php
                    }
                ?>
            </div>
        </div>
    </div>

    <div class="container-fluid bg-light">
        <div class="container p-3 bg-white">
            <?php
            include "config.php";
            $sql = "SELECT * FROM blogs";
            $result = mysqli_query($con, $sql) or die("Query Failed.");
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)) {
            ?>
            <div class="row m-2 bg-light">
                <div class="col-md-4 p-2">
                    <img class="single-feature-image" src="upload/<?php echo $row['img']; ?>" />
                </div>
                <div class="col-md-8">
                    <h3><?php echo $row['title']; ?></h3>
                    <div class="post-information">
                        <span>
                            <i class="fa fa-user m-2" aria-hidden="true"></i><?php echo $row['userName']; ?>
                        </span>
                        <span>
                            <i class="fa fa-calendar m-2" aria-hidden="true"></i>
                            <?php echo $row['created_at']; ?>
                        </span>
                    </div>
                    <p class="description">
                        <?php echo $row['descri']; ?>
                    </p>
                </div>
            </div>
            <div class="container px-3">
                <h5>Comments</h5>
                <?php  include "config.php";
                    $bid = $row["blog_id"];
                    $querycomments = "SELECT * FROM comments WHERE reply_id='0' AND post_id='$bid'";
                    $resultcomment = mysqli_query($con, $querycomments) or die("Query Failed.");
                    if(mysqli_num_rows($resultcomment) > 0){
                        while($rowc = mysqli_fetch_assoc($resultcomment)) {
                    ?>
                    <div class="row">
                        <div class="col-7">
                            <p><?php echo $rowc['userName']; ?>-<?php echo $rowc['created_at']; ?>:-
                            <?php echo $rowc['comment']; ?></p>
                        </div>
                        <div class="col-5">
                        <div class="row">
                            <div class="col-8 bg-light">
                                <?php  include "config.php";
                                $bid1 = $row["blog_id"];
                                $reply_id = $rowc['comment_id'];
                                $queryreply = "SELECT * FROM comments WHERE reply_id = '$reply_id'";
                                $resulreply = mysqli_query($con, $queryreply) or die("Query Failed.");
                                if(mysqli_num_rows($resulreply) > 0){
                                    while($rowr = mysqli_fetch_assoc($resulreply)) {
                                ?>
                                <p><?php echo $rowr['userName']; ?>-<?php echo $rowr['created_at']; ?>:-<br>
                                <?php echo $rowr['comment']; ?></p>
                                <?php 
                                    }
                                }?>
                            </div>
                            <div class="col-4">
                                <div class="btn btn-info" data-id="<?php echo $rowc['comment_id']; ?>" onclick="showReplyForm(this);">Reply</div>
                            </div>
                        </div>
                        </div>
                    </div>
                        <?php 
                        $commentid = $rowc['comment_id'];
                        foreach ($comments as $commentid): ?>
                            <form action="user.php" method="post" id="form-<?php echo $rowc['comment_id']; ?>" style="display: none;">
                                <input type="hidden" name="reply_id" value="<?php echo $rowc['comment_id']; ?>" required>
                                <input type="hidden" name="post_id" value="<?php echo $bid; ?>" required>
                                <textarea name="comment" class="form-control" rows="1" placeholder="Add Reply" required></textarea>
                                <input type="submit" class="btn btn-info" value="Reply" name="reply">
                            </form>
                        <?php endforeach; ?>
                    <?php 
                        }
                    }?>
                <form action="user.php" method="post">
                    <input type="hidden" name="post_id" value="<?php echo $bid; ?>" required>
                    <textarea name="comment" class="form-control" rows="1" placeholder="Add Comments" required></textarea>
                    <input type="submit" class="btn btn-info" value="Comment" name="blogcomment">
                </form>
            </div>
            <?php
                }
            }else{
                echo "<h2>No Record Found.</h2>";
            }
            ?>
        </div>
    </div>
    
</body>
</html>