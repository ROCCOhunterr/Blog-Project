<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "blogger";

$con= mysqli_connect("$server", "$username", "$password", "$database") or die("Connection Failed");

?>