<?php 
session_start();
if(isset($_POST['save'])){
    include('config.php');
    
    if(isset($_FILES['fileToUpload'])){

        $fileName = $_FILES['fileToUpload']['name'];
        $fileSize = $_FILES['fileToUpload']['size'];
        $fileTmp = $_FILES['fileToUpload']['tmp_name'];

        if(move_uploaded_file($fileTmp, "upload/".$fileName)){
        }
        else{
            echo "Could not upload the file.";
        }
    }

    $title = mysqli_real_escape_string($con, $_POST['title']);
    $description = mysqli_real_escape_string($con, $_POST['descri']);
    $userName = mysqli_real_escape_string($con, $_POST['userName']);
    $date = date('m/d/Y h:i:s a', time());

    $sql = "INSERT INTO blogs(title, descri, img, userName) 
    VALUES('$title', '$description','$fileName', '$userName')";
    if(mysqli_query($con, $sql)){
        header("Location: blogger.php");
        exit(0);
    }
    else{
        echo "Something Went Wrong!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Simple Bloger/User Interface</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container-fluid" id="header">
        <div class="container-fluid p-4" id="dashboard">
            <div class="row text-center h-100">
                <div class="col-4">
                    <h3>Blogger Dashboard</h3>
                </div>
                <div class="col-8">
                    <h3>Hello <?php echo $_SESSION["username"]; ?>, <a href="logout.php" class="admin-logout">Logout</a></h3>
                </div>
            </div>
        </div>
        <div class="container p-1" id="userBloger">
            <div class="d-grid gap-2 d-md-block">
                <a class="btn" href="user.php" role="button">Blogs</a>
                <?php include('config.php');
                    if($_SESSION["rol"] == '1'){
                ?>
                    <a class="btn" href="blogger.php" role="button">Blogs List</a>
                <?php
                    }
                ?>
            </div>
        </div>
    </div>
    <div class="container" id="userBlogerMain">
        <div class="row p-2" id="blogform">
            <div class="col-6">All Blogs</div>
            <div class="col-6">
                <div class="d-grid d-md-flex justify-content-md-end">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal"> Add Blog</button>
                </div>
                <div class="modal" id="myModal">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="admin-heading">Add New Blogs</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <form  action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label for="title">Title:</label>
                                        <input type="text" name="title" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="description"> Description:</label>
                                        <textarea name="descri" class="form-control" rows="5"  required></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" for="firstName">Author Name:</label>
                                        <input required type="text" name="userName" class="form-control form-control-lg" placeholder="UserName" />
                                    </div>
                                    <div class="mb-3">
                                        <label for="img">Post image:</label>
                                        <input type="file" name="fileToUpload" required>
                                    </div>
                                    <div class="text-center">
                                    <input type="submit" name="save" class="btn btn-primary" value="Save" required />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <th>S.No.</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Date&Time</th>
                    <th>Update</th>
                    <th>Delete</th>
                </thead>
                <tbody>
                    <?php
                        include "config.php";
                        $username1 = $_SESSION["username"];
                        if($_SESSION["rol"] == '1'){
                            $sql = "SELECT blog_id, title, userName, created_at FROM blogs 
                            WHERE blogs.userName = '{$username1}'";
                            $result = mysqli_query($con, $sql) or die("Query Failed.");
                            if(mysqli_num_rows($result) > 0){
                                while($row = mysqli_fetch_assoc($result)) {
                        ?>
                            <tr>
                                <td><?php echo $row['blog_id']; ?></td>
                                <td><?php echo $row['title']; ?></td>
                                <td><?php echo $row['userName']; ?></td>
                                <td><?php echo $row['created_at']; ?></td>
                                <td>
                                    <a href='bloggerupdate.php?id=<?php echo $row['blog_id']; ?>'><i class='fa fa-edit'></i></a>
                                </td>
                                <td><a href='deleteblog.php?id=<?php echo $row['blog_id']; ?>'><i class='fa fa-trash-o'></i></a></td>
                            </tr>
                            <?php
                                }
                            }
                            else{
                                echo "<h3>No Results Found.</h3>";
                            }
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    
</body>
</html>
      

