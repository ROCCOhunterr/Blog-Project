<?php
    include "config.php";
    session_start();

    $blogid = $_GET["id"];

    $sql1 = "SELECT * FROM blogs WHERE blog_id = {$blogid}";
    $result = mysqli_query($con, $sql1) or die("Query Failed : Select");
    $row = mysqli_fetch_assoc($result);

    unlink("upload/".$row['img']);

    $sql = "DELETE FROM blogs WHERE blogs.blog_id = {$blogid};";

   if(mysqli_multi_query($con, $sql)){
        header("Location: blogger.php");
        exit(0);
    }
    else{
        echo "Something Went Wrong!";
    }
?>
