<?php
session_start();
if(isset($_POST['update'])){
    include('config.php');
    $blogid = $_POST['blog_id'];
    $title = addslashes($_POST["title"]);
    $description = addslashes($_POST["descri"]);
    $username = addslashes($_POST["username"]);
    if(empty($_FILES['img']['name'])){
        $fileName = $_POST['oldImage'];
    }
    else{
        $fileName = $_FILES['fileToUpload']['name'];
        $fileSize = $_FILES['fileToUpload']['size'];
        $fileTmp = $_FILES['fileToUpload']['tmp_name'];

        if(move_uploaded_file($fileTmp, "upload/".$fileName)){
        }
        else{
            echo "Could not upload the file.";
        }
    }
    $sql = "UPDATE blogs SET title='$title', descri='$description', username='$username', img='$fileName' 
    WHERE blogs.blog_id = '$blogid'";
    $result = mysqli_query($con, $sql) or die("Query Failed.");
    if($result){
        header("Location: blogger.php");
        exit(0);
    }
    else{
        echo "Something Went Wrong!";
    }
    
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Simple Bloger/User Interface</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="modal-header">
            <h1 class="admin-heading">Edit Blogs</h1>
            <a href='blogger.php'><button type="button" class="btn-close" data-bs-dismiss="modal"></button></a>
        </div>
        <div class="modal-body">
        <?php
            include "config.php";
            $blogid = $_GET["id"];
            $query = "SELECT blog_id, title, descri, username, img 
            FROM blogs
            WHERE blogs.blog_id = '$blogid'";
            $result1 = mysqli_query($con, $query) or die("Query Failed.");
            if(mysqli_num_rows($result1) > 0){
                while($row = mysqli_fetch_assoc($result1)) {
                    ?>
            <form  action="bloggerupdate.php" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="blogid">S.No.:</label>
                    <input type="text" name="blog_id" class="form-control" value="<?php echo $row['blog_id']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="title">Title:</label>
                    <input type="text" name="title" class="form-control" value="<?php echo $row['title']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="description"> Description:</label>
                    <textarea name="descri" class="form-control" rows="5"><?php echo $row['descri']; ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="firstName">Author Name:</label>
                    <input required type="text" name="username" class="form-control" value="<?php echo $row['username']; ?>" placeholder="UserName" />
                </div>
                <div class="mb-3">
                    <label for="img">Post image:</label>
                    <input type="file" name="fileToUpload">
                    <img src="upload/<?php echo $row['img']; ?>" height="200px">
                    <input type="show" name="oldImage" value="<?php echo $row['img']; ?>">
                </div>
                <div class="text-center">
                <input type="submit" name="update" class="btn btn-primary" value="Update" />
                </div>
            </form>
            <?php
                }
            }
            else{
                echo "<h3>No Update Found.</h3>";
            }
            ?>
        </div>
    </div>



</body>
</html>
